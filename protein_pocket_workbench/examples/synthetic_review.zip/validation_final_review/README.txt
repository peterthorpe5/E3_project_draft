Extract the entire ZIP, then open index.html in Chrome, Firefox, Edge or Safari with WebGL enabled. No Python or server account is required.
To continue analyses in the workbench, extract app_resource.zip and open the resulting project directory containing project.json.
The HTML review does not execute new predictions or alignments.
